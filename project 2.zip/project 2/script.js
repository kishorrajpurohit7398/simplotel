const bar = document.getElementsByClassName("bar");
const nav=document.getElementsByClassName("narbar");
if(bar){
    bar.addEventlistener('click', () => {
        nav.classlist.add('active'),
    })
}